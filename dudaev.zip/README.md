# node-ddos-bot
this script executes requests to sites from ./utils/linksArray.js

how to use:
you can run builded files from ./build
OR
install node.js version 16.13.2 and run in terminal "npm i && npm run start"
