const linksArray = [
  "https://google.com/",
];

module.exports = Array.from(new Set(linksArray));
