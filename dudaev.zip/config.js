const PASSWORD = "HMEZYjR4hY464MnA6QxkTRCb";

module.exports = {PASSWORD};